<?php

namespace app\api\model;

use think\Model;

class UserBankModel extends Model{
	protected $table = 'ly_user_bank';

	/** 添加银行卡 **/
	public function addBankCard(){
		//获取参数	token、name、card_no、bank_name、bank_branch_name
		$post 		= input('post.');
		
		$token		= input('post.token/s');		
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];

		$name				= input('post.name/s');			// 持卡人姓名
		$card_no			= input('post.card_no/d');		// 银行卡账号
		$bank_name			= input('post.bank_name/s');	// 银行名称
		$bank_id			= input('post.bank_id/s');	// 银行名称
		$bank_branch_name	= input('post.bank_branch_name/s');	// 支行名称
		$remark				= input('post.remark/s');			// 备注
		
		/* 数据验证 */
		if(empty($name))	return ['code' => 2, 'code_dec'	=> '持卡人姓名为空'];
		if(empty($card_no))	return ['code' => 2, 'code_dec'	=> '银行卡账号为空'];
		if(empty($bank_name))	return ['code' => 2, 'code_dec'	=> '银行名称为空'];
		if(empty($bank_branch_name))	return ['code' => 2, 'code_dec'	=> '支行名称为空'];
		if(empty($remark))	$remark	= '';
		
		// 验证银行卡账号
		$cardlength	= strlen($card_no);
		switch($cardlength){	// 验证银行卡号长度
			case 15:
			case 16:
			case 17:
			case 18:
			case 19:
				
			break;
			default:
				return ['code'	=> 0, 'code_dec' => '银行卡号长度错误'];
			break;
		}
		preg_match("/^([1-9]{1})(\d{14,18})$/",$card_no,$matches);		
		if(!$matches[0]) return ['code'	=> 3, 'code_dec' => '银行卡格式不正确'];
		
		//实名信息
		$realname = Model('Users')->where('id',$uid)->value('realname');
		if($realname){
			if($name != $realname){
				$data['code']		= 0;
				$data['code_dec']	= '银行卡姓名与实名信息不一致,请重新输入';
				return $data;
			}
		}else{
			//更新用户名
			model('Users')->where('id',$uid)->update(array('realname'=>$name));
		}

		// 防止银行卡重复使用
		$bankcard_account	= $this->where(['card_no'=>$card_no])->find();
		if($bankcard_account){
			switch($bankcard_account['status']){
				case 1:	// 银行卡已存在，并正常使用
					return ['code'	=> 4, 'code_dec' => '卡号已绑定'];
				break;
				case 3:	// 原来已经添加过的银行卡，但后来被逻辑删除，现再次添加的处理
					$undelete_bankInfo	= $this->where('id',$bankcard_account['id'])->update(['status'=>1]);
					return ['code'	=> 1, 'code_dec' => '银行卡添加成功'];
				break;
			}
		}
		
		// 绑定新增银行卡
		$bankCard_arr = array(
			'uid'				=> $uid,			
			'name'				=> $name,		// 持卡人姓名
			'bid'					=> $bank_id,
			'card_no'			=> $card_no,	// 银行卡卡号
			'bank_name'			=> $bank_name,			// 银行名称
			'bank_branch_name'	=> $bank_branch_name,	// 支行名称
			'remark'			=> $remark,	// 备注
			'add_time'			=> time(),
		);
		$insert_ok = $this->insert($bankCard_arr);
		if(!$insert_ok)	return	['code'	=> 0, 'code_dec' => '银行卡添加失败'];
		return ['code'	=> 1, 'code_dec' => '银行卡添加成功'];
	}
	
	
	/** 获取银行卡列表 **/
	public function getBankCardList(){
		// 获取参数		
		$token 		= input('post.token/s');		
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];
		
		// 获取数据
		$bankCard_arr = $this->where('uid',$uid)->where('status',1)->order('id desc')->select()->toArray();
		
		if(!count($bankCard_arr))	return	['code'	=> 0, 'code_dec' => '没有绑定的银行卡'];
		
		// 返回数组
		$data['code'] = 1;
		foreach($bankCard_arr as $key =>$value){
			$data['data'][$key]['id']			= $value['id']; 
			$data['data'][$key]['card_no']		= $value['card_no'];		// 银行卡账号
			$data['data'][$key]['bank_name']	= $value['bank_name'];		// 银行名称
			$data['data'][$key]['bank_branch_name']	= $value['bank_branch_name'];		// 支行名称
			$data['data'][$key]['name']			= $value['name'];			// 持卡人姓名
			$data['data'][$key]['remark']		= $value['remark'];			// 备注
		}
				
		return $data;
	}
	
	
	/** 获取银行卡信息 **/
	public function getBankCardInfo(){
		// 获取参数		
		$token 		= input('post.token/s');		
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];
		$card_no	= input('post.card_no/d','','strip_tags,trim');	// 银行卡号
		
		// 获取数据
		$bankCardInfo = $this->where(['uid'=>$uid,'card_no'=>$card_no])->find();
		if(!$bankCardInfo)	return	['code'	=> 0, 'code_dec' => '没有绑定的银行卡'];
		
		// 返回数组
		$data['data']['id']			= $bankCardInfo['id']; 
		$data['data']['card_no']	= $bankCardInfo['card_no'];	// 银行卡账号
		$data['data']['bank_name']	= model('Bank')->where('id',$bankCardInfo['bid'])->value('bank_name');	// 银行名称
		$data['data']['bank_branch_name']	= $bankCardInfo['bank_branch_name'];	// 支行名称
		$data['data']['name']		= $bankCardInfo['name'];		// 持卡人姓名
		$data['data']['remark']		= $bankCardInfo['remark'];		// 备注
		$data['data']['status']		= $bankCardInfo['status'];		// 银行卡状态：1=正常；2=锁定；3=删除
		
		return $data;
	}
	
	
	/**  修改银行卡信息	 **/
	public function changeBankCardInfo(){
		///获取参数
		$token = input('post.token/s');		
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];
		$card_no	= input('post.card_no/d','','strip_tags,trim');	// 银行卡号
		$act		= input('post.action/d');	// 银行卡修改操作
		
		//获取数据
		$bankCardId = $this->where(['uid'=>$uid,'card_no'=>$card_no])->value('id');
		if(!$bankCardId)	return	['code'	=> 0, 'code_dec' => '银行卡不存在'];
		
		switch($act){
			case '1':	// 银行卡删除
				$isDel_bankInfo	= $this->where('id',$bankCardId)->update(['status'=>3]);

				if(!$isDel_bankInfo)	return	['code'	=> 0, 'code_dec' => '删除失败'];

				return ['code' => 1, 'code_dec'	=> '删除成功'];
			break;
			case '2':	// 银行卡锁定
				$isLocking		= $this->where('id',$bankCardId)->update(['status'=>2]);
				
				if(!$isLocking)		return	['code'	=> 0, 'code_dec' => '锁定失败'];
				
				return ['code' => 1, 'code_dec'	=> '银行卡锁定成功'];
			break;
			case '3':	// 银行卡解锁
				$isUnlocking		= $this->where('id',$bankCardId)->update(['status'=>1]);
				
				if(!$isUnlocking)	return	['code'	=> 0, 'code_dec' => '解锁失败'];
				
				return ['code' => 1, 'code_dec'	=> '银行卡解锁成功'];
			break;
		}
	}
}
