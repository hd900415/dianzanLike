<?php
namespace app\api\model;

use think\Model;

class UserTotalModel extends Model{
	// 表名
	protected $table = 'ly_user_total';

	/**
	 * 获取用户余额
	 */
	public function getUserBalance(){
		//获取参数
		$token 		= input('post.token/s');
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];//uid
		$username 	= $userArr[1];//username

		$param 		= input('post.');

		$user_id = model('Users')->where('id',$uid)->value('id');
		
		if(!$user_id){
			$data	= [
				'code'		=> 0,
				'code_dec'	=> '数据获取失败'
			];
			return $data;
		}

		$balance = $this->where('uid',$uid)->value('balance');

		$data['balance'] 	= round($balance,3);
		$data['code'] 		= 1;
		$data['code_dec']	= '成功';
		return $data;			
	}

	/*
		第三方红包扣钱
	*/
	public function ko(){
		//获取参数
		$param 		=	input('post.');
		$token 		=	$param['token'];
		$userArr	=	explode(',',auth_code($token,'DECODE'));
		$uid		=	$userArr[0];//uid
		$username 	=	$userArr[1];//username
		$money		=	$param['money'];
		$type		=	$param['type'];
		
		$balance 	= 	$this->where('uid',$uid)->value('balance');

		switch($type){
			case 'f'://发
			
				if($balance < $money)	return 0;
				
				if($param['fid']){//私发
					$s_hb	=	model('Users')->where('id',$uid)->value('s_hb');
					if($s_hb==2){//不能私发
						return 0;
					}
				}
				
				$vip_level	=	model('Users')->where('id',$uid)->value('vip_level');
					if($vip_level < 2){//不能发
						return 2;
					}

				$is_update_user_b = $this->where('uid',$uid)->setDec('balance', $money);
				
				if(!$is_update_user_b) return 0;
				
				// 产生流水
				$financial_data['uid'] 						= $uid;
				$financial_data['username'] 				= $username;
				$financial_data['order_number'] 			= 'HB'.trading_number();
				$financial_data['trade_number'] 			= 'L'.trading_number();
				$financial_data['trade_type'] 				= 14;
				$financial_data['trade_before_balance']		= $balance;
				$financial_data['trade_amount'] 			= $money;
				$financial_data['account_balance'] 			= $balance - $money;
				$financial_data['remarks'] 					= '发放红包';
				
				model('TradeDetails')->tradeDetails($financial_data);
				
				return 1;

			break;
			case 'q'://抢
				
				$is_update_user_b =  $this->where('uid',$uid)->Inc('balance', $money)->update();
				
				if(!$is_update_user_b) return 0;
				
				// 产生流水
				$financial_data['uid'] 						= $uid;
				$financial_data['username'] 				= $username;
				$financial_data['order_number'] 			= 'HB'.trading_number();
				$financial_data['trade_number'] 			= 'L'.trading_number();
				$financial_data['trade_type'] 				= 15;
				$financial_data['trade_before_balance']		= $balance;
				$financial_data['trade_amount'] 			= $money;
				$financial_data['account_balance'] 			= $balance + $money;
				$financial_data['remarks'] 					= '领取红包';
				
				model('TradeDetails')->tradeDetails($financial_data);
				return 1;
			break;
		}

		return 0;
	}

	
	
}
