<?php

namespace app\api\model;

use think\Model;

class HomelogModel extends Model{
	//表名
	protected $table = 'ly_homelog';
	
}