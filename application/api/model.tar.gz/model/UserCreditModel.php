<?php

/**
 * 编写：祝踏岚
 * 用于获取系统设置数据
 */

namespace app\api\model;

use think\Model;

class UserCreditModel extends Model{
	//表名
	protected $table = 'ly_user_credit';
	
	/**
		获取用户积分信息
	**/
	public function getUserCreditList(){
		//获取参数
		$token 		= input('post.token/s');
		$userArr	= explode(',',auth_code($token,'DECODE'));
		$uid		= $userArr[0];
		$lang		= (input('post.lang')) ? input('post.lang') : 'cn';	// 语言类型
		
		$is_user	= model('Users')->where('id', $uid)->count();
		//检测用户
		if($is_user){
			if($lang=='cn'){
				return ['code' => 0, 'code_dec' => '用户不存在'];
			}else{
				return ['code' => 0, 'code_dec' => 'user does not exist!'];
			}
		}
		
		$countNum	= $this->where('uid', $uid)->count();		
		if(!$countNum){
			$data['code'] = 0;
			if($lang=='cn') $data['code_dec']	= '没有数据';
			else $data['code_dec']	= 'No data!';
			return $data;
		}

		//每页记录数
		$pageSize	= (isset($param['page_size']) and $param['page_size']) ? $param['page_size'] : 10;
		//当前页
		$pageNo		= (isset($param['page_no']) and $param['page_no']) ? $param['page_no'] : 1;
		//总页数
		$pageTotal	= ceil($countNum / $pageSize); //当前页数大于最后页数，取最后
		//偏移量
		$limitOffset	= ($pageNo - 1) * $pageSize;
			
		$userBuyVipList	= $this->where('uid', $uid)->order('stime desc')->limit($limitOffset, $pageSize)->select();
		if(is_object($userBuyVipList)) $userBuyVipListArray = $userBuyVipList->toArray();
		
		//获取成功
		$data['code'] 				= 1;
		$data['data_total_nums'] 	= $countNum;
		$data['data_total_page'] 	= $pageTotal;
		$data['data_current_page'] 	= $pageNo;
		
		//数组重组赋值
		foreach ($userBuyVipListArray as $key => $value) {			
			$data['info'][$key]['id'] 		= $value['id'];
			$data['info'][$key]['uid'] 		= $value['uid'];
			$data['info'][$key]['username'] = $value['username'];
			$data['info'][$key]['credit'] 	= $value['credit'];
			$data['info'][$key]['remarks'] 	= $value['remarks'];
			$data['info'][$key]['time'] 	= date('Y-m-d H:i:s',$value['time']);
		}

		return $data;
	}

}