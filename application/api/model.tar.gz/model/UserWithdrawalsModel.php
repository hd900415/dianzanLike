<?php
namespace app\api\model;
use think\model;
use app\api\validate\UserTotal as UserTotalValidate;

class UserWithdrawalsModel extends model
{
	protected $table = 'ly_user_withdrawals';

	/**
	 * [draw 提现接口]
	 * @return [type] [description]
	 */
	public function draw(){
		//获取参数
		$post 		= input('post.');
		$token 		= input('post.token/s');		
		$userArr	= explode(',',auth_code($token,'DECODE'));//uid,username
		$uid		= $userArr[0];//uid
		$username	= $userArr[1];//username
		$lang		= (input('post.lang')) ? input('post.lang') : 'cn';	// 语言类型
		/*laoli--------------------------------------------------------start*/
		//查询用户类型——测试用户类型不允许提现
		$userType = model('users')->where('id',$uid)->value('user_type');
		if($userType == 3){
			return ['code' => 0, 'code_dec' => '测试用户类型不允许提现'];
		}
		$userState = model('users')->where('id',$uid)->value('state');
		if($userState != 1){
			return ['code' => 0, 'code_dec' => '会员不可提现'];
		}
		/*laoli--------------------------------------------------------end*/
		
		$drawtime = cache('C_DrawTime_'.$uid) ? cache('C_DrawTime_'.$uid) : time()-2;
		//2秒
		if(time()-$drawtime < 2){
			return ['code' => 0, 'code_dec' => '2s内不能连续提交'];
		}
		cache('C_DrawTime_'.$uid,time()+2);
		
		//判断是否可以提现
		$withdrawals_state = model('Users')->where(array('id'=>$uid,'withdrawals_state'=>1))->count();

		if(!$withdrawals_state){
			return ['code' => 0, 'code_dec' => '未开启提现功能'];
		}
		//低以50不能提现
		$credit = model('users')->where('id',$uid)->value('credit');
		if($credit<50){
			return ['code' => 0, 'code_dec' => '信用低以50不能提现'];
		}
		//提现范围
		
		$settingData = model('Setting')->where('id',1)->find();
		
		if(($post['draw_money'] < $settingData['min_w']) || ($post['draw_money'] > $settingData['max_w'])){
			return ['code' => 0, 'code_dec' => '提现金额不在范围内'];
		}
		
		
		//数据验证
		$validate = validate('app\api\validate\UserTotal');
		if(!$validate->scene('draw')->check($post)){
			$data['code'] = $validate->getError();
			switch($data['code']){
				case 3:
					$data['code_dec']	= '提现金额不在范围内';
				break;
				case 4:
					$data['code_dec']	= '资金密码有误';
				break;
				case 5:
					$data['code_dec']	= '余额不足';
				break;
				case 6:
					$data['code_dec']	= '提现渠道有误';
				break;
				case 7:
					$data['code_dec']	= '提现银行卡有误';
				break;
				case 8:
					$data['code_dec']	= '提现银行有误';
				break;
				default:
					$data['code_dec']	= '提现失败';
		  }
		  
			if($lang=='cn'){
				return ['code' => $data['code'], 'code_dec' => $data['code_dec']];
			}else{
				return ['code' => 0, 'code_dec' => 'Fail'];
			}
		}
		
		
		//获取当天提现次数
		$where[] = ['time' , '>=' ,mktime(0,0,0,date('m'),date('d'),date('Y'))];
		$where[] = ['time' , '<=' ,mktime(23,59,59,date('m'),date('d'),date('Y'))];
		$where[] = ['uid' , '=' , $uid];

		$num = $this->where($where)->count();		
		if($num > 9){
				return ['code' => 0, 'code_dec' => '超过当日最大体现次数'];
		}
		$draw_type = input('post.draw_type/s');
		switch($draw_type){
			case 'bank':
				//获取用户绑定银行信息
				$user_bank = model('UserBank')->where('id',$post['user_bank_id'])->find();
			break;
			case 'alipay':
				$Usersinfo = Model('Users')->where('id',$uid)->where('alipay',$post['user_bank_id'])->find();
				$user_bank['card_no']	=	$Usersinfo['alipay'];
				$user_bank['name']		=	$Usersinfo['alipay_name'];
				$user_bank['bid']		=	0;
			break;
		}

		$carry['uid']			=	$uid;		
		$carry['price']			=	$post['draw_money'];		
		$carry['card_name']		=	$user_bank['name'];//户名
		$carry['card_number']	=	$user_bank['card_no'];//卡号
		$carry['bank_id']		=	$user_bank['bid'];//银行ID
		$carry['time']			=	time();
		$carry['order_number']	=	trading_number();
		$carry['trade_number']	=	trading_number();
		$carry['remarks']		=	'尊敬的用户您好！您的编号为'.$carry['order_number'].' 的提现处理中，金额￥'.$post['draw_money'].'元 服务费：￥0.0000元，处理时间：'.date('Y-m-d H:i:s',$carry['time']);
		/*$isinsert = $this->insert($carry);
		if(!$isinsert){
			$data['code'] 		= 0;
			$data['code_dec']	= '提现失败';
			return $data;
		}*/
		//用户余额
		$cbalance = model('UserTotal')->where('uid',$uid)->value('balance');
		//更新余额
		$map[] = array('uid','=',$uid);
		$map[] = array('balance','>=',$post['draw_money']);
		$isupdata = model('UserTotal')->where($map)->setDec('balance',$post['draw_money']);
		if(!$isupdata){
			return ['code' => 0, 'code_dec' => '业务失败1'];
		}
		$isinsert = $this->insert($carry);
		if(!$isinsert){
			return ['code' => 0, 'code_dec' => '业务失败2'];
		}
		//添加流水
		$financial_data['uid']					=	$uid;
		$financial_data['username']				=	$username;		
		$financial_data['sid']					=	$uid;		
		$financial_data['state']				=	3;		
		$financial_data['order_number']			=	$carry['order_number'];		
		$financial_data['trade_number']			=	$carry['trade_number'];		
		$financial_data['trade_type']			=	2;		
		$financial_data['trade_before_balance']	=	$cbalance;		
		$financial_data['trade_amount']			=	$post['draw_money'];		
		$financial_data['account_balance']		=	$cbalance - $post['draw_money'];		
		$financial_data['remarks']				=	'平台取款';
		$financial_data['vip_level']			=	model('Users')->where('id',$uid)->value('vip_level');
		$financial_data['isdaily']				=	2;
		$insert = model('TradeDetails')->tradeDetails($financial_data);	
		if(!$insert){
			return ['code' => 0, 'code_dec' => '业务失败3'];
		}
		if($lang=='cn'){
			return ['code' => 1, 'code_dec' => '成功'];
		}else{
			return ['code' => 1, 'code_dec' => 'Success'];
		}
	}
	/**
	 * 提现记录
	 */
	public function getUserWithdrawalsList(){
		//获取参数
		$token 		= input('post.token/s');
		$userArr	= explode(',',auth_code($token,'DECODE'));//uid,username
		$uid		= $userArr[0];//uid
		$username 	= $userArr[1];//username

		$param 		= input('post.');

		if(!$uid){
			$data['code'] = 0;
			return $data;
		}

		$where[] = array('uid','=',$uid);

		//状态
		if (isset($param['state']) and $param['state']) {
			$where[] = array('state','=',$param['state']);
		}
		/*//开始时间
		if (isset($param['search_time_s']) and $param['search_time_s']) {
			$where[] = array('time','>=',strtotime($param['search_time_s']));
		} else {
			$where[] = array('time','>=',mktime(0,0,0,date('m'),date('d'),date('Y')));
		}
		//结束时间
		if (isset($param['search_time_e']) and $param['search_time_e']) {
			$where[] = array('time','<=',strtotime($param['search_time_e']));
		} else {
			$where[] = array('time','<=',mktime(23,59,59,date('m'),date('d'),date('Y')));
		}*/

		//分页
		//总记录数
		$count = $this->where($where)->count();
		if(!$count){
			$data['code'] = 0;
			$data['code_dec']	= '暂无记录';
			return $data;
		}
		//每页记录数
		$pageSize = (isset($param['page_size']) and $param['page_size']) ? $param['page_size'] : 10;
		//当前页
		$pageNo = (isset($param['page_no']) and $param['page_no']) ? $param['page_no'] : 1;
		//总页数
		$pageTotal = ceil($count / $pageSize); //当前页数大于最后页数，取最后
		//偏移量
		$limitOffset = ($pageNo - 1) * $pageSize;

		$dataAll = $this->where($where)
						->order(['time'=>'desc','id'=>'desc'])
						->limit($limitOffset, $pageSize)
						->select();

		if (!$dataAll) {
			$data['code'] = 0;
			$data['code_dec']	= '暂无记录';
			return $data;
		}

		//获取成功
		$data['code'] 				= 1;
		$data['data_total_nums'] 	= $count;
		$data['data_total_page'] 	= $pageTotal;
		$data['data_current_page'] 	= $pageNo;

		//数组重组赋值
		foreach ($dataAll as $key => $value) {
			$rmoney = 0;
			if($value['state'] == 1 || $value['state'] == 6)
			{
				$rmoney = $value['price'];
			}
			$data['info'][$key]['dan'] 			= $value['order_number'];
			$data['info'][$key]['adddate'] 		= date('Y-m-d H:i:s',$value['time']);
			$data['info'][$key]['real_name'] 	= mb_substr($value['card_name'],0,1,"utf-8").'**';
			$data['info'][$key]['bank_no_tail'] = substr_replace($value['card_number'],'*************',0,-4);
			$data['info'][$key]['money'] 		= $value['price'];
			$data['info'][$key]['rmoney'] 		= $rmoney;//($value['state'] == 1) ? $value['price'] : 0;
			$data['info'][$key]['status_desc'] 	= config('custom.withdrawalsState')[$value['state']];
			$data['info'][$key]['remark'] 		= $value['remarks'];
			$data['info'][$key]['typedes'] 		= '提现';
		}

		return $data;
	}

	/**
	 * 团队提现
	 */
	public function teamWithdrawals(){
		//获取参数并过滤
		$param 				= input('param.');
		$param['user_id'] 	= input('param.user_id/d');

		if(!$param['user_id']){
			$data['code'] = 0;
			return $data;
		}

		$where[] = array('user_team.uid','=',$param['user_id']);
		$where[] = array('user_team.team','neq',$param['user_id']);

		//用户名搜索
		if (isset($param['username']) and $param['username']) {
			$where[] = array('username','=',$param['username']);
		}
		//状态
		if (isset($param['state']) and $param['state']) {
			$where[] = array('ly_user_withdrawals.state','=',$param['state']);
		}
		//开始时间
		if (isset($param['search_time_s']) and $param['search_time_s']) {
			$where[] = array('time','>=',strtotime($param['search_time_s']));
		} else {
			$where[] = array('time','>=',mktime(0,0,0,date('m'),date('d'),date('Y')));
		}
		//结束时间
		if (isset($param['search_time_e']) and $param['search_time_e']) {
			$where[] = array('time','<=',strtotime($param['search_time_e']));
		} else {
			$where[] = array('time','<=',mktime(23,59,59,date('m'),date('d'),date('Y')));
		}

		//分页
		//总记录数
		$count = $this->join('users','ly_user_withdrawals.uid = users.id')->join('user_team','ly_user_withdrawals.uid = user_team.team')->where($where)->count();
		//每页记录数
		$pageSize = (isset($param['page_size']) and $param['page_size']) ? $param['page_size'] : 10;
		//当前页
		$pageNo = (isset($param['page_no']) and $param['page_no']) ? $param['page_no'] : 1;
		//总页数
		$pageTotal = ceil($count / $pageSize); //当前页数大于最后页数，取最后
		//偏移量
		$limitOffset = ($pageNo - 1) * $pageSize;

		//数据
		$dataArray = $this->field('ly_user_withdrawals.*,users.username')
							->join('users','ly_user_withdrawals.uid = users.id')
							->join('user_team','ly_user_withdrawals.uid = user_team.team')
							->where($where)
							->order('time','desc')
							->limit($limitOffset, $pageSize)
							->select();

		if (!$dataArray) {
			$data['code'] = 0;
			return $data;
		}

		//获取成功
		$data['code'] 				= 1;
		$data['data_total_nums'] 	= $count;
		$data['data_total_page'] 	= $pageTotal;
		$data['data_current_page'] 	= $pageNo;
		$decimalPlace = config('api.decimalPlace');
		foreach($dataArray as $key => $value){
			$rmoney = 0;
			if($value['state'] == 1 || $value['state'] == 6)
			{
				$rmoney = $value['price'];
			}
			$value['fee'] = round($value['fee'],$decimalPlace);
			$value['price'] = round($value['price'],$decimalPlace);
			$rmoney = round($rmoney,$decimalPlace);
			$data['info'][$key]['dan']                  =   $value['order_number'];
			$data['info'][$key]['adddate']              =   date('Y-m-d H:i:s',$value['time']);
			$data['info'][$key]['username']             =   $value['username'];
			$data['info'][$key]['real_name']            =   mb_substr($value['card_name'],0,1,"utf-8").'**';
			$data['info'][$key]['fee']             	    =   $value['fee'];
			$data['info'][$key]['bank_no_tail']         =   substr_replace($value['card_number'],'*******************',0,-4);
			$data['info'][$key]['money']                =   $value['price'];
			$data['info'][$key]['rmoney']				=	$rmoney;//($value['state'] == 1) ? $value['price'] : 0;
			$data['info'][$key]['status_desc']          =   config('custom.withdrawalsState')[$value['state']];
			$data['info'][$key]['remarks']				=	$value['remarks'];
		}

		return $data;
	}
}
