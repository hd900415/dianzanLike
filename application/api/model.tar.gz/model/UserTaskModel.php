<?php
namespace app\api\model;

use think\Model;

class UserTaskModel extends Model
{
	protected $table = 'ly_user_task';

}